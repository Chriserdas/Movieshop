let config = {
    host:"localhost",
    user:"root",
    database:"tvondemand",
    password:"password",
};

module.exports = config;